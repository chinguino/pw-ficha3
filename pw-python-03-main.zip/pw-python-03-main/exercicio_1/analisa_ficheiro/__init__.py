from analisa_ficheiro.acessorio import *
from analisa_ficheiro.calculos import * 
