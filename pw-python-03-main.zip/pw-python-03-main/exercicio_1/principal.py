import json
import analisa_ficheiro

#print(analisa_ficheiro.pede_nome("bola.txt"))
print(analisa_ficheiro.gera_nome("bola.txt"))
print(analisa_ficheiro.calcula_linhas("bola.txt"))
print(analisa_ficheiro.calcula_carateres("bola.txt"))
print(analisa_ficheiro.calcula_palavra_comprida("bola.txt"))
print(analisa_ficheiro.calcula_ocorrencia_de_letras("bola.txt"))