import analise_pasta

#analise_pasta.pede_pasta()
analise_pasta.faz_calculos()
analise_pasta.guarda_resultados(analise_pasta.faz_calculos())
analise_pasta.faz_grafico_barras(analise_pasta.faz_calculos())
analise_pasta.faz_grafico_queijos(analise_pasta.faz_calculos())